﻿using System;

namespace ClinicManagement.Core.ViewModel
{
    public class AppointmentSearchVM
    {
        public string Name { get; set; }
        public string Option { get; set; }
        public DateTime Date { get; set; }
    }
}